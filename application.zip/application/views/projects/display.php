<div class="col-xs-9">
	<h1>Project Name: <?php echo $project_data->project_name; ?></h1>
	<p>Date Created:  <?php echo $project_data->date_created; ?></p>
	<h3>Description</h3>
	<p><?php echo $project_data->project_body; ?></p>
</div>

<div class="col-xs-3 pull-right">
	<ul>
		<h4>Project Actions</h4>
			<li class="list-group-item"><a href="http://localhost/ci/index.php/projects/create">Create Task</a></li>
			<li class="list-group-item"><a href="http://localhost/ci/index.php/projects/edit/<?php echo $project_data->id; ?>">Edit Task</a></li>
			<li class="list-group-item"><a href="http://localhost/ci/index.php/projects/delete/<?php echo $project_data->id; ?>">Delete Task</a></li>
		
	</ul>
</div>