<h1>Projects</h1>


<p class="bg-success">
	
	<?php if($this->session->flashdata('project_created')): ?>
		<?php echo $this->session->flashdata('project_created'); ?>
	<?php endif; ?>


	<?php if($this->session->flashdata('project_updated')): ?>
		<?php echo $this->session->flashdata('project_updated'); ?>
	<?php endif; ?>

	<?php if($this->session->flashdata('project_deleted')): ?>
		<?php echo $this->session->flashdata('project_deleted'); ?>
	<?php endif; ?>

</p>

<a class= "btn btn-primary pull-right" href="http://localhost/ci/index.php/projects/create">Create Poject</a>

<table class = "table table-hover">
	<thead>
		<tr>
			<th>Project Name</th>
			<th>Project Body</th>
		</tr>
	</thead>

	<tbody>
		<?php foreach($projects as $project): ?>
		<tr>
			<?php echo "<td><a href='http://localhost/ci/index.php/projects/display/".$project->id."'>".$project->project_name."</a></td>"; ?>
			<?php echo "<td>".$project->project_body."</td>"; ?>
			<td><a class="btn btn-danger" href="http://localhost/ci/index.php/projects/delete/<?php echo $project->id; ?>"><span class="glyphicon glyphicon-remove"></span></a></td>
		</tr>
 
			
		 
		<?php endforeach; ?>
	</tbody>
</table>